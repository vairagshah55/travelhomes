const express = require("express");
const router = express.Router();

const {
  withMobile,
  verifyOtp,
  withEmail,
  signUp,
  signIn,
  deleteusers,
  adminLogin,
  deleteadmins,
  googleAuth
} = require("../controller/Authcontroller");

router.post("/register/mobile", withMobile);
router.post("/register/verifyotp", verifyOtp);
router.post("/register/emailverification", withEmail);
router.post("/register/signup", signUp);
router.post("/login", signIn);
router.post("/adminlogin", adminLogin);
router.post("/google", googleAuth);
router.get("/deleteusers", deleteusers);
router.get("/deleteadmins", deleteadmins);

module.exports = router;